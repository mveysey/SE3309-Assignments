//requiring express
const express = require("express");
const bodyParser = require("body-parser");
const newConnection = require("./DBConnection");
const { Router } = require("express");

const app = express();

app.use(express.static("static"));

app.use(
  express.urlencoded({
    extended: true,
  })
);

app.get("/", (req, res) => {});

app.get("/Test", (req, res) => {
  let conn = newConnection();
  conn.connect();

  conn.query(`DROP TABLE Test`, (err, rows, fields) => {
    if (err) console.log(err);
    else console.log("Table Dropped");
  });

  conn.query(
    `CREATE TABLE Test
    (
        test varchar(25)
    )`,
    (err, rows, fields) => {
      if (err) console.log(err);
      else console.log("Test table created");
    }
  );
  conn.end();
});

// Top American movies directed by user entered director
app.get("/TopMByD", (req, res) => {
  let conn = newConnection();
  conn.connect();

  let firstName, lastName;
  firstName = req.query.first;
  lastName = req.query.last;

  conn.query(
    `
  SELECT m.title
  FROM movie m, direction d
  WHERE m.originatingCountry LIKE '%United States%' AND m.title = d.title AND d.fName = "${firstName}" AND d.lName = "${lastName}";
  `,
    (err, rows, fields) => {
      if (err) console.log(err);
      else {
        movies = rows;

        let content =
          "<h1>" +
          " <strong>" +
          "Movies from the United States directed by " +
          firstName +
          " " +
          lastName +
          ":" +
          " <strong>" +
          "</h1>";
        content += "<br><br>";
        for (m of movies) {
          content += "<div>";
          content += "<font size='+3'>" + m.title + "</font>";
          content += "</div>";
          content += "\n";
        }

        res.send(
          "<div style='background-color: PowderBlue'>" + content + "</div>"
        );
      }
    }
  );
  conn.end();
});

// Top 10 movies being watched in the United States (country)
app.get("/Top10Country", (req, res) => {
  let conn = newConnection();
  conn.connect();

  let country;
  country = req.query.country;

  conn.query(
    `
  SELECT movie.title, user.location,
  (SELECT SUM(review.rating)/COUNT(*)
  FROM review
  WHERE review.title = movie.title) AS raters
  FROM movie, user WHERE user.location = "${country}" ORDER BY raters DESC LIMIT 10;
  `,
    (err, rows, fields) => {
      if (err) console.log(err);
      else {
        movies = rows;

        let count = 1;
        let content =
          "<h1>" +
          " <strong>" +
          "Top 10 movies being watched in " +
          country +
          ":" +
          " </strong>" +
          "</h1>";
        content += "<br><br>";
        for (m of movies) {
          content += "<div>";
          content +=
            "<font size='+3'>" +
            "#" +
            count +
            ". Title: " +
            m.title +
            " | Rating: " +
            m.raters +
            "</font>";
          content += "</div>";
          content += "\n";
          content += "<br><br>";
          count++;
        }

        res.send(
          "<div style='background-color: PowderBlue'>" + content + "</div>"
        );
      }
    }
  );
  conn.end();
});

// Movies that won a certain award in a certain genre in a certain country
app.get("/AwardWinningGenre", (req, res) => {
  let conn = newConnection();
  conn.connect();

  let genre, awardName, country;
  genre = req.query.genre;
  awardName = req.query.awardName;
  country = req.query.country;

  conn.query(
    `
    SELECT DISTINCT m.title, ma.awardName
    FROM movie m, genre g, movieAward ma
    WHERE EXISTS (SELECT title, awardName FROM movieAward) AND g.genreType = "${genre}" AND ma.awardName = "${awardName}" AND m.originatingCountry = "${country}";
  `,
    (err, rows, fields) => {
      if (err) console.log(err);
      else {
        movies = rows;

        let content =
          "<h1>" +
          " <strong>" +
          "Titles of genre " +
          genre +
          " that won award " +
          awardName +
          " that was created in " +
          country +
          ":" +
          "</strong>" +
          "<h1>";
        content += "<br><br>";
        for (m of movies) {
          content += "<div>";
          content += "<font size='+3'>" + "- Title: " + m.title + "</font>";
          content += "</div>";
          content += "\n";
          content += "<br><br>";
        }

        res.send(
          "<div style='background-color: PowderBlue'>" + content + "</div>"
        );
      }
    }
  );
  conn.end();
});

// Movies leaving soon by genre
app.get("/LeavingSoonGenre", (req, res) => {
  let conn = newConnection();
  conn.connect();

  let genre1;
  genre1 = req.query.genre1;

  conn.query(
    `
    SELECT movie.title
    FROM moviesgenre, movie, contract
    WHERE genreType = "${genre1}" AND moviesgenre.title = movie.title AND movie.contractStartDate = contract.contractStartDate AND contract.contractEndDate >= 2022-01-01;
  `,
    (err, rows, fields) => {
      if (err) console.log(err);
      else {
        movies = rows;

        let content =
          "<h1>" +
          "<strong>" +
          "Movies in the genre " +
          genre1 +
          " that are leaving soon:" +
          "</strong>" +
          "</h1>";

        for (m of movies) {
          content += "<div>";
          content += "<font size='+3'>" + "- Title: " + m.title + "</font>";
          content += "</div>";
          content += "\n";
          content += "<br><br>";
        }

        res.send(
          "<div style='background-color: PowderBlue'>" + content + "</div>"
        );
      }
    }
  );
  conn.end();
});

// View Reviews for a specific movie
app.get("/viewReviewsMovie", (req, res) => {
  let conn = newConnection();
  conn.connect();

  let title;
  title = req.query.titles;
  conn.query(
    `
    SELECT review.title, review.date, review.rating, user.fName, user.lName
    FROM review
    INNER JOIN user ON review.emailAddress = user.emailAddress WHERE review.title = "${title}";
  `,
    (err, rows, fields) => {
      if (err) console.log(err);
      else {
        movies = rows;

        let content =
          "<h1>" +
          "<strong>" +
          "Reviews for " +
          title +
          ":" +
          "</strong>" +
          "</h1>";

        for (m of movies) {
          content += "<div>";
          content +=
            "<font size='+3'>" +
            "Title: " +
            m.title +
            " | Date: " +
            m.date +
            " | Rating: " +
            m.rating +
            " | User Name: " +
            m.fName +
            " " +
            m.lName +
            "</font>";
          content += "</div>";
          content += "\n";
          content += "<br><br>";
        }

        res.send(
          "<div style='background-color: PowderBlue'>" + content + "</div>"
        );
      }
    }
  );
  conn.end();
});

// Allow user to add a review
app.get("/addReview", (req, res) => {
  let conn = newConnection();
  conn.connect();

  let title, date, emailAddress, rating;
  title = req.query.titles;
  date = req.query.date;
  emailAddress = req.query.emailAddress;
  rating = req.query.rating;

  conn.query(
    `
    INSERT INTO review
      SET rating = "${rating}",
      date = "${date}",
      title = (
        SELECT title
        FROM movie
        WHERE title = "${title}"
      ), 
      emailAddress = (
        SELECT emailAddress
        FROM logincredentials
        WHERE emailAddress = "${emailAddress}"
      )
  `,
    (err, rows, fields) => {
      if (err) console.log(err);
      else {
        res.redirect("/reviews.html");
      }
    }
  );
  conn.end();
});

// Login as admin
app.post("/login", (req, res) => {
  let userName = req.body.usr;
  let password = req.body.pwd;
  let message = "Access Denied";

  if (userName == "admin" && password == "time123") {
    message = "Welcome Admin!";
    //go to the admin page
    res.redirect("editGenre.html");
  }
  res.send(message);
});

// Edit Genre
app.get("/editgenre", (req, res) => {
  let conn = newConnection();
  conn.connect();

  let newName, oldName;
  newName = req.query.newName;
  oldName = req.query.oldName;

  conn.query(
    `
    UPDATE moviesgenre
    SET genreType = "${newName}"
    WHERE genreType = "${oldName}";
  `,
    (err, rows, fields) => {
      if (err) console.log(err);
      else {
        res.redirect("editGenre.html");
      }
    }
  );
  conn.end();
});

//method to close it
app.get("/close", (req, res) => {
  res.send("<script> window.close(); </script>");
});

app.listen(3000);
