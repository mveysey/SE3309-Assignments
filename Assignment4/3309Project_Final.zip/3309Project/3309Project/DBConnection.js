const mysql = require("mysql");

function newConnection() {
  let conn = mysql.createConnection({
    host: "localhost",
    port: "3306",
    user: "root",
    password: "Mialma5@Canada",
    database: "1200blockbusters+",
  });

  return conn;
}

module.exports = newConnection;
